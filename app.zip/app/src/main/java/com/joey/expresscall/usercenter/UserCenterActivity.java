
package com.joey.expresscall.usercenter;

import com.joey.general.BaseActivity;

public class UserCenterActivity extends BaseActivity {

    @Override
    protected void initSettings() {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected void initUi() {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected void saveSettings() {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected void freeMe() {
        // TODO Auto-generated method stub
        
    }

   

}
